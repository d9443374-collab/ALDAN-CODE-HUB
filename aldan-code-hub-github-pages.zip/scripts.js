const snippets = [
{title:"Tombol Alert JavaScript",lang:"JavaScript",cat:"JavaScript",desc:"Menampilkan pesan sederhana saat tombol ditekan.",code:`function tampilkanPesan() {\n  alert("Halo! Selamat belajar coding.");\n}`},
{title:"Jam Digital",lang:"JavaScript",cat:"JavaScript",desc:"Jam digital yang memperbarui waktu setiap detik.",code:`function updateJam() {\n  const sekarang = new Date();\n  document.querySelector("#jam").textContent =\n    sekarang.toLocaleTimeString("id-ID");\n}\nsetInterval(updateJam, 1000);\nupdateJam();`},
{title:"Dark Mode Toggle",lang:"JavaScript",cat:"UI",desc:"Mengganti tema halaman dengan class CSS.",code:`function toggleTema() {\n  document.body.classList.toggle("dark-mode");\n}`},
{title:"Kalkulator Sederhana",lang:"JavaScript",cat:"JavaScript",desc:"Contoh fungsi penjumlahan dua angka.",code:`function tambah(a, b) {\n  return Number(a) + Number(b);\n}\nconsole.log(tambah(12, 8)); // 20`},
{title:"Kartu Profil HTML",lang:"HTML",cat:"HTML & CSS",desc:"Struktur kartu profil sederhana.",code:`<article class="profile-card">\n  <h2>Nama Kamu</h2>\n  <p>Web Developer Pemula</p>\n  <a href="#kontak">Hubungi saya</a>\n</article>`},
{title:"CSS Gradient Text",lang:"CSS",cat:"HTML & CSS",desc:"Membuat teks dengan warna gradasi.",code:`.gradient-text {\n  background: linear-gradient(90deg, #55aaff, #55e0d0);\n  -webkit-background-clip: text;\n  background-clip: text;\n  color: transparent;\n}`},
{title:"Flexbox Center",lang:"CSS",cat:"HTML & CSS",desc:"Menempatkan elemen tepat di tengah.",code:`.container {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  min-height: 100vh;\n}`},
{title:"Python: Sapaan",lang:"Python",cat:"Python",desc:"Fungsi sederhana untuk menyapa pengguna.",code:`def sapa(nama):\n    return f"Halo, {nama}! Selamat belajar."\n\nprint(sapa("Aldan"))`},
{title:"Python: Cek Bilangan",lang:"Python",cat:"Python",desc:"Memeriksa apakah angka genap atau ganjil.",code:`angka = 17\n\nif angka % 2 == 0:\n    print("Genap")\nelse:\n    print("Ganjil")`},
{title:"Python: List",lang:"Python",cat:"Python",desc:"Menyimpan dan menampilkan daftar data.",code:`buah = ["apel", "mangga", "jeruk"]\n\nfor item in buah:\n    print(item)`},
{title:"PHP: Tampilkan Teks",lang:"PHP",cat:"Backend",desc:"Contoh output dasar PHP.",code:`<?php\n$nama = "Aldan";\necho "Halo, " . $nama;\n?>`},
{title:"SQL: Buat Tabel",lang:"SQL",cat:"Database",desc:"Membuat tabel pengguna sederhana.",code:`CREATE TABLE pengguna (\n  id INTEGER PRIMARY KEY,\n  nama VARCHAR(100) NOT NULL,\n  email VARCHAR(150) UNIQUE\n);`},
{title:"SQL: Ambil Data",lang:"SQL",cat:"Database",desc:"Mengambil semua data dari sebuah tabel.",code:`SELECT id, nama, email\nFROM pengguna\nORDER BY nama ASC;`},
{title:"Bash: Info Folder",lang:"Bash",cat:"Terminal",desc:"Melihat lokasi dan isi folder saat ini.",code:`pwd\nls -la`},
{title:"JSON: Contoh Data",lang:"JSON",cat:"Data",desc:"Format data sederhana untuk pertukaran informasi.",code:`{\n  "nama": "Aldan",\n  "proyek": "Code Hub",\n  "aktif": true,\n  "minat": ["HTML", "CSS", "JavaScript"]\n}`},
{title:"Java: Hello World",lang:"Java",cat:"Lainnya",desc:"Program Java pertama untuk menampilkan teks.",code:`public class Main {\n  public static void main(String[] args) {\n    System.out.println("Hello, World!");\n  }\n}`},
{title:"C++: Hello World",lang:"C++",cat:"Lainnya",desc:"Program dasar C++.",code:`#include <iostream>\nusing namespace std;\n\nint main() {\n  cout << "Hello, World!" << endl;\n  return 0;\n}`},
{title:"Python: Tanggal Hari Ini",lang:"Python",cat:"Python",desc:"Menampilkan tanggal lokal saat program dijalankan.",code:`from datetime import date\n\nhari_ini = date.today()\nprint(hari_ini.strftime("%d-%m-%Y"))`}
];

const grid = document.querySelector("#code-grid");
const search = document.querySelector("#search");
const language = document.querySelector("#language-filter");
const chips = document.querySelector("#category-chips");
const categories = ["Semua","HTML & CSS","JavaScript","Python","Backend","Database","Terminal","Data","UI","Lainnya"];
let activeCategory = "Semua";

function escapeHTML(value) {
  return value.replace(/[&<>"']/g, char => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[char]));
}
function render() {
  const term = search.value.toLowerCase().trim();
  const selectedLang = language.value;
  const filtered = snippets.filter(item =>
    (activeCategory === "Semua" || item.cat === activeCategory) &&
    (selectedLang === "all" || item.lang === selectedLang) &&
    (item.title + " " + item.lang + " " + item.desc + " " + item.code).toLowerCase().includes(term)
  );
  grid.innerHTML = filtered.map((item, index) => `
    <article class="code-card">
      <div class="card-head"><h3>${escapeHTML(item.title)}</h3><span class="tag">${escapeHTML(item.lang)}</span></div>
      <p class="card-desc">${escapeHTML(item.desc)}</p>
      <div class="code-wrap"><button class="copy-btn" data-index="${snippets.indexOf(item)}">COPY ⧉</button><pre><code>${escapeHTML(item.code)}</code></pre></div>
      <div class="card-foot">SNIPPET / ${String(index + 1).padStart(2,"0")}</div>
    </article>`).join("");
  document.querySelector("#shown-count").textContent = `${filtered.length} dari ${snippets.length} script`;
  document.querySelector("#empty-state").hidden = filtered.length !== 0;
  grid.querySelectorAll(".copy-btn").forEach(button => button.addEventListener("click", () => copyCode(Number(button.dataset.index))));
}
async function copyCode(index) {
  try {
    await navigator.clipboard.writeText(snippets[index].code);
    showToast("Kode berhasil disalin!");
  } catch {
    showToast("Clipboard tidak tersedia di browser ini.");
  }
}
let toastTimer;
function showToast(message) {
  const toast = document.querySelector("#toast");
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 1800);
}
categories.forEach(category => {
  const button = document.createElement("button");
  button.className = "chip" + (category === "Semua" ? " active" : "");
  button.textContent = category;
  button.addEventListener("click", () => {
    activeCategory = category;
    chips.querySelectorAll(".chip").forEach(chip => chip.classList.toggle("active", chip.textContent === category));
    render();
  });
  chips.append(button);
});
[...new Set(snippets.map(item => item.lang))].sort().forEach(lang => {
  const option = document.createElement("option");
  option.value = lang;
  option.textContent = lang;
  language.append(option);
});
search.addEventListener("input", render);
language.addEventListener("change", render);
document.querySelector("#total-count").textContent = snippets.length;
document.querySelector("#year").textContent = new Date().getFullYear();
render();
