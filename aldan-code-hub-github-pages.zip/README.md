# ALDAN CODE HUB

Website perpustakaan snippet coding statis. Tidak memerlukan database, server, atau instalasi tambahan.

## Isi
- `index.html` — struktur halaman
- `style.css` — desain responsif
- `scripts.js` — daftar snippet, pencarian, filter, dan tombol salin

## Menjalankan di Android
1. Download dan ekstrak ZIP.
2. Buka folder hasil ekstrak di Acode.
3. Buka `index.html` lalu pilih Preview/browser.

## Hosting gratis dengan GitHub Pages
1. Login ke https://github.com
2. Tekan tombol **+** lalu **New repository**.
3. Isi nama repository, misalnya `aldan-code-hub`.
4. Pilih **Public**, lalu buat repository.
5. Masuk repository → **Add file** → **Upload files**.
6. Upload `index.html`, `style.css`, dan `scripts.js` (bukan folder ZIP).
7. Tekan **Commit changes**.
8. Buka **Settings** → **Pages**.
9. Pada **Build and deployment**, pilih **Deploy from a branch**.
10. Pilih branch **main**, folder **/(root)**, lalu **Save**.
11. Tunggu proses selesai. Alamat situs biasanya:
   `https://USERNAME.github.io/aldan-code-hub/`

Ganti `USERNAME` dengan username GitHub kamu.

## Menambah snippet
Buka `scripts.js`, lalu tambahkan objek baru ke dalam array `snippets`:

```js
{
  title: "Nama Script",
  lang: "JavaScript",
  cat: "JavaScript",
  desc: "Penjelasan singkat fungsi kode.",
  code: `console.log("Halo dunia");`
},
```

Pastikan setiap objek dipisahkan koma. Setelah mengubah file, upload ulang atau edit file tersebut di GitHub.

## Catatan
Contoh kode disediakan untuk pembelajaran. Periksa dan pahami kode sebelum menggunakannya dalam proyek.
